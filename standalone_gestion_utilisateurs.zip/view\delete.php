<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: listeUtilisateurs.php');
    exit();
}
include_once '../controller/UtilisateurC.php';

if (isset($_GET['id'])) {
    $uc = new UtilisateurC();
    $uc->DeleteUtilisateur($_GET['id']);
}
header('Location: listeUtilisateurs.php');
?>
