<?php
include_once 'header.php';
include_once '../controller/AuthC.php';

$error = '';
if (isset($_POST['email']) && isset($_POST['password'])) {
    $auth = new AuthC();
    $user = $auth->login($_POST['email'], $_POST['password']);
    
    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
        
        // Seul cet email obtient le rôle 'admin', les autres sont 'user'
        if (strtolower(trim($user['email'])) === 'admin@workify.com') {
            $_SESSION['user_role'] = 'admin';
        } else {
            $_SESSION['user_role'] = 'user';
        }
        
        header("Location: listeUtilisateurs.php");
        exit();
    } else {
        $error = "Email ou mot de passe incorrect.";
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <h2 class="text-center mb-4 text-primary fw-bold">Connexion</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><i class="fa-solid fa-circle-exclamation me-2"></i><?= $error ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="mb-3">
                <label class="form-label">Adresse Email</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-envelope"></i></span>
                    <input type="email" class="form-control" name="email" placeholder="Entrez votre email" required>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label">Mot de passe</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" class="form-control" name="password" placeholder="Entrez votre mot de passe" required>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Se connecter à Workify</button>
        </form>
    </div>
</div>

<?php include_once 'footer.php'; ?>
