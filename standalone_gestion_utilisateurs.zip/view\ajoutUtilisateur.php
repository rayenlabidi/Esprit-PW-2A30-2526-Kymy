<?php
include_once 'header.php';
if ($_SESSION['user_role'] !== 'admin') {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Accès refusé. Seuls les administrateurs peuvent ajouter des utilisateurs.</div></div>";
    include_once 'footer.php';
    exit();
}
include_once '../controller/UtilisateurC.php';
$uc = new UtilisateurC();
$roles = $uc->ListeRoles();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0 text-dark"><i class="fa-solid fa-user-plus me-2"></i>Ajouter un Utilisateur</h2>
    <a href="listeUtilisateurs.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Retour à la liste</a>
</div>

<form action="addUtilisateur.php" method="POST" class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Role</label>
        <select name="role_id" class="form-select" required>
            <option value="">Sélectionner un rôle...</option>
            <?php foreach ($roles as $role) { ?>
                <option value="<?= $role['id'] ?>"><?= htmlspecialchars(ucfirst($role['name'])) ?></option>
            <?php } ?>
        </select>
    </div>
    
    <div class="col-md-6">
        <label class="form-label">Statut</label>
        <select name="status" class="form-select">
            <option value="active">Actif</option>
            <option value="inactive">Inactif</option>
        </select>
    </div>

    <div class="col-md-6">
        <label class="form-label">Prénom</label>
        <input type="text" class="form-control" name="first_name" required>
    </div>

    <div class="col-md-6">
        <label class="form-label">Nom</label>
        <input type="text" class="form-control" name="last_name" required>
    </div>

    <div class="col-md-6">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required>
    </div>

    <div class="col-md-6">
        <label class="form-label">Mot de passe</label>
        <input type="password" class="form-control" name="password" required>
    </div>

    <div class="col-12">
        <label class="form-label">Titre professionnel (Headline)</label>
        <input type="text" class="form-control" name="headline" placeholder="Ex: Développeur PHP" required>
    </div>

    <div class="col-12">
        <label class="form-label">Biographie</label>
        <textarea class="form-control" name="bio" rows="4" required></textarea>
    </div>

    <div class="col-12 text-end mt-4">
        <button type="submit" class="btn btn-primary px-4 py-2"><i class="fa-solid fa-check me-2"></i>Créer l'utilisateur</button>
    </div>
</form>

<?php include_once 'footer.php'; ?>
