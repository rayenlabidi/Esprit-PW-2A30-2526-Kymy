<?php
include_once 'header.php';
if ($_SESSION['user_role'] !== 'admin') {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Accès refusé. Seuls les administrateurs peuvent modifier des utilisateurs.</div></div>";
    include_once 'footer.php';
    exit();
}
include_once '../Model/utilisateur.php';
include_once '../controller/UtilisateurC.php';

$uc = new UtilisateurC();
$roles = $uc->ListeRoles();

$userToForm = null;
if (isset($_GET['id'])) {
    $userToForm = $uc->RecupererUtilisateur($_GET['id']);
}

if (isset($_POST['id']) && isset($_POST['role_id']) && isset($_POST['first_name']) && isset($_POST['last_name'])) {
    $user = new utilisateur(
        (int)$_POST['role_id'],
        $_POST['first_name'],
        $_POST['last_name'],
        $_POST['email'],
        $_POST['password'] ?? '',
        $_POST['headline'] ?? '',
        $_POST['bio'] ?? '',
        $_POST['status'] ?? 'active'
    );
    
    $uc->UpdateUtilisateur($user, $_POST['id']);
    header('Location: listeUtilisateurs.php');
    exit();
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0 text-dark"><i class="fa-solid fa-user-pen me-2"></i>Modifier l'Utilisateur</h2>
    <a href="listeUtilisateurs.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Retour à la liste</a>
</div>

<?php if ($userToForm) { ?>
    <form action="" method="POST" class="row g-3">
        <input type="hidden" name="id" value="<?= htmlspecialchars($userToForm['id']) ?>">

        <div class="col-md-6">
            <label class="form-label">Role</label>
            <select name="role_id" class="form-select" required>
                <?php foreach ($roles as $role) { ?>
                    <option value="<?= $role['id'] ?>" <?= $role['id'] == $userToForm['role_id'] ? 'selected' : '' ?>><?= htmlspecialchars(ucfirst($role['name'])) ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="col-md-6">
            <label class="form-label">Statut</label>
            <select name="status" class="form-select">
                <option value="active" <?= $userToForm['status'] == 'active' ? 'selected' : '' ?>>Actif</option>
                <option value="inactive" <?= $userToForm['status'] == 'inactive' ? 'selected' : '' ?>>Inactif</option>
            </select>
        </div>

        <div class="col-md-6">
            <label class="form-label">Prénom</label>
            <input type="text" class="form-control" name="first_name" value="<?= htmlspecialchars($userToForm['first_name']) ?>" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Nom</label>
            <input type="text" class="form-control" name="last_name" value="<?= htmlspecialchars($userToForm['last_name']) ?>" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($userToForm['email']) ?>" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Nouveau Mot de passe <span class="text-muted small">(laisser vide pour ne pas changer)</span></label>
            <input type="password" class="form-control" name="password">
        </div>

        <div class="col-12">
            <label class="form-label">Titre professionnel (Headline)</label>
            <input type="text" class="form-control" name="headline" value="<?= htmlspecialchars($userToForm['headline']) ?>">
        </div>

        <div class="col-12">
            <label class="form-label">Biographie</label>
            <textarea class="form-control" name="bio" rows="4"><?= htmlspecialchars($userToForm['bio']) ?></textarea>
        </div>

        <div class="col-12 text-end mt-4">
            <button type="submit" class="btn btn-primary px-4 py-2"><i class="fa-solid fa-floppy-disk me-2"></i>Mettre à jour</button>
        </div>
    </form>
<?php } else { ?>
    <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Utilisateur non trouvé.</div>
<?php } ?>

<?php include_once 'footer.php'; ?>
