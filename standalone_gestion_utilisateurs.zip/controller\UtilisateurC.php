<?php
include_once "../config.php";

class UtilisateurC
{
    public function ListeUtilisateurs()
    {
        $db = config::getConnexion();
        try {
            $liste = $db->query('SELECT u.*, r.name AS role_name FROM utilisateurs u LEFT JOIN roles r ON r.id = u.role_id ORDER BY u.created_at DESC');
            return $liste;
        } catch (Exception $e) {
            die("Error: " . $e->getMessage());
        }
    }

    public function RecupererUtilisateur($id)
    {
        $sql = "SELECT * FROM utilisateurs WHERE id= :id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute(['id' => $id]);
            return $query->fetch();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    public function ListeRoles()
    {
        $db = config::getConnexion();
        try {
            $liste = $db->query('SELECT * FROM roles ORDER BY id');
            return $liste;
        } catch (Exception $e) {
            die("Error: " . $e->getMessage());
        }
    }

    public function AddUtilisateur($u)
    {
        $sql = "INSERT INTO utilisateurs (role_id, first_name, last_name, email, password, headline, bio, status) 
                VALUES (:role_id, :first_name, :last_name, :email, :password, :headline, :bio, :status)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'role_id'    => $u->getRoleId(),
                'first_name' => $u->getFirstName(),
                'last_name'  => $u->getLastName(),
                'email'      => $u->getEmail(),
                'password'   => password_hash($u->getPassword(), PASSWORD_DEFAULT),
                'headline'   => $u->getHeadline(),
                'bio'        => $u->getBio(),
                'status'     => $u->getStatus()
            ]);
        } catch (Exception $e) {
            echo 'Erreur: ' . $e->getMessage();
        }
    }

    public function DeleteUtilisateur($id)
    {
        $sql = "DELETE FROM utilisateurs WHERE id = :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    public function UpdateUtilisateur($u, $id)
    {
        try {
            $db = config::getConnexion();
            
            if (empty($u->getPassword())) {
                $query = $db->prepare(
                    'UPDATE utilisateurs SET 
                        role_id = :role_id,
                        first_name = :first_name, 
                        last_name = :last_name, 
                        email = :email,
                        headline = :headline,
                        bio = :bio,
                        status = :status
                    WHERE id = :id'
                );
                $query->execute([
                    'role_id'    => $u->getRoleId(),
                    'first_name' => $u->getFirstName(),
                    'last_name'  => $u->getLastName(),
                    'email'      => $u->getEmail(),
                    'headline'   => $u->getHeadline(),
                    'bio'        => $u->getBio(),
                    'status'     => $u->getStatus(),
                    'id'         => $id
                ]);
            } else {
                $query = $db->prepare(
                    'UPDATE utilisateurs SET 
                        role_id = :role_id,
                        first_name = :first_name, 
                        last_name = :last_name, 
                        email = :email,
                        password = :password,
                        headline = :headline,
                        bio = :bio,
                        status = :status
                    WHERE id = :id'
                );
                $query->execute([
                    'role_id'    => $u->getRoleId(),
                    'first_name' => $u->getFirstName(),
                    'last_name'  => $u->getLastName(),
                    'email'      => $u->getEmail(),
                    'password'   => password_hash($u->getPassword(), PASSWORD_DEFAULT),
                    'headline'   => $u->getHeadline(),
                    'bio'        => $u->getBio(),
                    'status'     => $u->getStatus(),
                    'id'         => $id
                ]);
            }
        } catch (Exception $e) {
            echo "Erreur: " . $e->getMessage();
        }
    }
}
?>
