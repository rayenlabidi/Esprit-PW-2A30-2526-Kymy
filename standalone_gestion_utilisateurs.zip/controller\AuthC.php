<?php
include_once "../config.php";

class AuthC
{
    public function login($email, $password)
    {
        $db = config::getConnexion();
        try {
            $query = $db->prepare("SELECT u.*, r.name AS role_name FROM utilisateurs u LEFT JOIN roles r ON r.id = u.role_id WHERE u.email = :email");
            $query->execute(['email' => $email]);
            $user = $query->fetch();

            if ($user && password_verify($password, $user['password'])) {
                return $user; // Succès
            }
            return false; // Échec
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
}
?>
