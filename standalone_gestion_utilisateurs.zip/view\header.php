<?php
session_start();
$currentPage = basename($_SERVER['PHP_SELF']);
if ($currentPage !== 'login.php' && !isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Workify Users</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Inter', sans-serif; }
        .navbar-brand { font-size: 1.5rem; letter-spacing: -0.5px; }
        .card { border-radius: 10px; }
        .table th { background-color: #f1f4f8; color: #495057; font-weight: 600; }
        .form-label { font-weight: 500; color: #343a40; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold" href="listeUtilisateurs.php"><i class="fa-solid fa-briefcase me-2"></i>Workify</a>
    <?php if(isset($_SESSION['user_id'])): ?>
    <div class="d-flex align-items-center text-white">
        <span class="me-3"><i class="fa-solid fa-circle-user me-1"></i> <?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?></span>
        <a href="logout.php" class="btn btn-light btn-sm text-primary fw-bold"><i class="fa-solid fa-right-from-bracket me-1"></i>Déconnexion</a>
    </div>
    <?php endif; ?>
  </div>
</nav>

<div class="container">
    <div class="card shadow-sm border-0 mb-5">
        <div class="card-body p-4 p-md-5">
