<?php
include_once 'header.php';
include_once '../controller/UtilisateurC.php';

$uc = new UtilisateurC();
$liste = $uc->ListeUtilisateurs();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0 text-dark"><i class="fa-solid fa-users me-2"></i>Gestion des utilisateurs</h2>
    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
        <a href="ajoutUtilisateur.php" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i> Nouvel utilisateur</a>
    <?php endif; ?>
</div>

<div class="table-responsive">
    <table class="table table-hover align-middle border">
        <thead>
            <tr>
                <th>ID</th>
                <th>Role</th>
                <th>Utilisateur</th>
                <th>Email</th>
                <th>Statut</th>
                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                    <th class="text-end">Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($liste as $u) { 
                // Un "User" normal ne voit que sa propre ligne !
                if (isset($_SESSION['user_role']) && $_SESSION['user_role'] !== 'admin') {
                    if ($u['id'] != $_SESSION['user_id']) {
                        continue;
                    }
                }
            ?>
                <tr>
                    <td><span class="badge bg-secondary">#<?= $u['id']; ?></span></td>
                    <td>
                        <span class="badge <?= $u['role_name'] === 'admin' ? 'bg-danger' : 'bg-info text-dark' ?>">
                            <?= strtoupper($u['role_name'] ?: 'USER'); ?>
                        </span>
                    </td>
                    <td>
                        <div class="fw-bold"><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']); ?></div>
                        <div class="small text-muted"><?= htmlspecialchars($u['headline'] ?: 'Sans titre'); ?></div>
                    </td>
                    <td><?= htmlspecialchars($u['email']); ?></td>
                    <td>
                        <?php if($u['status'] === 'active'): ?>
                            <span class="badge bg-success">Actif</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">Inactif</span>
                        <?php endif; ?>
                    </td>
                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                        <td class="text-end">
                            <a href="update.php?id=<?= $u['id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a> 
                            <a href="delete.php?id=<?= $u['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?');"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include_once 'footer.php'; ?>
