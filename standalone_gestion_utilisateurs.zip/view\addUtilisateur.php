<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: listeUtilisateurs.php');
    exit();
}
include_once '../Model/utilisateur.php';
include_once '../controller/UtilisateurC.php';

if (
    isset($_POST['role_id']) &&
    isset($_POST['first_name']) &&
    isset($_POST['last_name']) &&
    isset($_POST['email']) &&
    isset($_POST['password']) &&
    isset($_POST['headline']) &&
    isset($_POST['bio']) &&
    isset($_POST['status'])
) {
    // We create the user instance
    $user = new utilisateur(
        (int)$_POST['role_id'],
        $_POST['first_name'],
        $_POST['last_name'],
        $_POST['email'],
        $_POST['password'],
        $_POST['headline'],
        $_POST['bio'],
        $_POST['status']
    );
    
    $uc = new UtilisateurC();
    $uc->AddUtilisateur($user);
    
    header('Location: listeUtilisateurs.php');
} else {
    echo "Paramètres manquants. Tous les champs sont désormais obligatoires.";
}
?>
